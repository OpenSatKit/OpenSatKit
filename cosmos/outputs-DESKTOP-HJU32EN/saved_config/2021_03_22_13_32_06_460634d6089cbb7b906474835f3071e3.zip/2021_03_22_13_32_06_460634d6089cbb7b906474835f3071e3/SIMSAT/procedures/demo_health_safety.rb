################################################################################
# SimSat Health & Safety App Group Demo 
#
# Notes:
#   1. Developed for the YouTube Health  Safety App Group  training video. This
#      demo uses SimSat configuration.
#      
# Demo Steps:
#   1.  
#
# License:
#   Written by David McComas, licensed under the copyleft GNU General Public
#   License (GPL).
#
################################################################################

require 'osk_global'
require 'osk_system'
require 'osk_flight'

require 'fsw_const'

#
# This demo intentionally corrupts a table being checksummed by CS so the 
# location of the table needs to be  
# These are the HS_AppData offsets to access the pointers to the first 
# data entry for each table. These offsets are valid for HS 2.3.0 using
# the compiler settings delivered with OSK0.
#
[536]    HS_XCTEntry_t   *XCTablePtr;  Execution Counters Table
[540]    HS_AMTEntry_t   *AMTablePtr;  Apps Monitor Table
[544]    HS_EMTEntry_t   *EMTablePtr;  Events Monitor Table
[548]    HS_MATEntry_t   *MATablePtr;  Message Actions Table

"CFE_ES" ACSII: 43 46 45 5F 45 53
"%" = 0x25


######################
## Global Variables ##
######################


###########
## Setup ##
###########

# Configure system 

Osk::System.check_n_start_cfs

# Configure apps - Done on a per step basis

# Open displays -  Done on a per step basis


############################################
## Step 1 - Display SimSat Configurations ##
############################################

# 1.1 - HK's copy table source file
Cosmos.run_process("ruby lib/OskTxtFileViewer -f '#{Osk::OSK_CFS_DIR}/apps/hk/fsw/tables/hk_cpy_tbl.c'")
status_bar("Observe two packets being defined: HK_COMBINED_PKT1_MID and HK_COMBINED_PKT2_MID")
wait  # <Go> to continue

# 1.2 - SimSat schedule table
Cosmos.run_process("ruby lib/OskTxtFileViewer -f '#{Osk::GND_TO_FLT_SRV_DIR}/osk_sch_sch_tbl.json'")
status_bar("Search for 'HK Combined Pkt' entries and note frequency and message table entry IDs")
wait  # <Go> to continue

# 1.3 - SimSat message table
Cosmos.run_process("ruby lib/OskTxtFileViewer -f '#{Osk::GND_TO_FLT_SRV_DIR}/osk_sch_msg_tbl.json'")
status_bar("Scroll to message table entry IDs noted in previous step or search for HK_COMBINED_PKT1_MID")
wait  # <Go> to continue


#####################################################
## Step 2 - Observe HK behavior without 42 running ##
#####################################################

display("SIMSAT DEMO_HK_SCREEN",1500,50)      

["CFE_ES", "CFE_EVS", "CFE_SB", "CFE_TBL", "CFE_TIME"].each do |app|
   Osk::flight.send_cmd(app,"NOOP") 
   wait 2
end

status_bar("Each command cFE app valid counter incremented. Combo packet counter increments. Missed data increments since 42 is not running")
wait  # <Go> to continue


##################################################
## Step 3 - Observe HK behavior with 42 running ##
##################################################

cmd("CFE_EVS ENA_APP_EVENT_TYPE with APP_NAME HK, BITMASK 0x01") # Enable debug events to view missed packets
status_bar("Observe missed data events")
wait  # <Go> to continue

Osk::System.start_42

status_bar("Observe missed data events and counter increments stop")
wait  # <Go> to continue


#############
## Cleanup ##
#############

cmd("CFE_EVS DIS_APP_EVENT_TYPE with APP_NAME HK, BITMASK 0x01")   # Disable debug events
   
clear("SIMSAT DEMO_HK_SCREEN")
