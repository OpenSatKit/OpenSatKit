CFDP TEST

In order the execute the tests, change 'testvars.rb' file for local definitions.
More detailed information inside the file.