# Use "target_name"_VCID to set a custom vcid for this target
PDU_VCID = 1

############################################
#               Command Defines            #
############################################
#CF_INCOMING_PDU_MID = 0x1FFD

############################################
#              Telemetry Defines           #
############################################
#CF_SPACE_TO_GND_PDU_MID = 0x0FFD